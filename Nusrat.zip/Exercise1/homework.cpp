#include <iostream>
#include <string>
using namespace std;

/* Exercise 1: Class Creation */

////////////////////////////////////////////////////
// Write your class here

class Employee {
public:
    int age;
    int experience;
    int salary;

    // Constructor with default values
    Employee(int a = 30, int e = 5, int s = 2000) {
        age = a;
        experience = e;
        salary = s;
    }

    // Calculate 25% tax
    int calculateTax() {
        return salary * 25 / 100;
    }

    // Print employee information
    void printInfo() {
        cout << "Age: " << age << endl;
        cout << "Experience: " << experience << endl;
        cout << "Salary: " << salary << endl;
        cout << "Tax: " << calculateTax() << endl;
    }
};

// Do not touch anything below this line
////////////////////////////////////////////////////

int main(int argc, char* argv[]) {

    int test = stoi(argv[1]);
    int age = stoi(argv[2]);
    int experience = stoi(argv[3]);
    int salary = stoi(argv[4]);

    Employee employee(age, experience, salary);

    switch (test)
    {
        case 1:
        {
            cout << employee.age << " "
                 << employee.experience << " "
                 << employee.salary;
            break;
        }

        case 2:
        {
            employee.printInfo();
            break;
        }

        case 3:
        {
            Employee employee;

            cout << employee.age << " "
                 << employee.experience << " "
                 << employee.salary;
            break;
        }

        case 4:
        {
            cout << employee.calculateTax();
            break;
        }
    }

    return 0;
}
